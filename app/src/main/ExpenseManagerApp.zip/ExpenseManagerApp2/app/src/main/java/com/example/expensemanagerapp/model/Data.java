package com.example.expensemanagerapp.model;

public class Data {


    private int amount;
    private String item;
    private String postdate;



    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getPostdate() {
        return postdate;
    }

    public void setPostdate(String date) {
        this.postdate = date;
    }


}
