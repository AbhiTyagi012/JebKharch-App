package com.example.expensemanagerapp.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expensemanagerapp.R;
import com.example.expensemanagerapp.model.Data;

import java.util.List;

public class UploadAdapter extends RecyclerView.Adapter<UploadAdapter.MyView> {
    private List<Data> list;
    public UploadAdapter(List<Data> list) {
        this.list= list;
        Log.e("error", "adapter" );
    }

    @NonNull
    @Override
    public MyView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_upload,parent,false);
        return new MyView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyView holder, int position) {

        Log.e("error1","execute");
        Data data =list.get(position);


        holder.tproductname.setText(data.getItem());
        holder.tproductamt.setText(data.getAmount());
        holder.tdate.setText(data.getPostdate());
        Log.e("error1",data.getItem());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

     class MyView extends RecyclerView.ViewHolder{
        private TextView tproductname,tproductamt,tdate;


         public MyView(@NonNull View itemView) {
             super(itemView);
             tproductname=itemView.findViewById(R.id.productname);
             tproductamt=itemView.findViewById(R.id.productamount);
             tdate=itemView.findViewById(R.id.productdate);

         }
     }
}
